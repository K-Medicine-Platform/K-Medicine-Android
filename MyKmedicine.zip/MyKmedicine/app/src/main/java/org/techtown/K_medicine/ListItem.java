package org.techtown.K_medicine;

public class ListItem {
    private String btnText;

    public ListItem(String text){
        btnText = text;
    }

    public String getText(){
        return btnText;
    }
}
